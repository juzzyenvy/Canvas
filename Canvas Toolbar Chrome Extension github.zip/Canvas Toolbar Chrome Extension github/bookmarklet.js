/**
 * The script.src value needs to be set to the URL of the raw JS file 'toolbar.js'.
 */
(function() {
    var script=document.createElement('script');
    script.src='https://cdn.jsdelivr.net/gh/juzzyenvy/Canvas/toolbar.js';
    document.head.appendChild(script);
}())