/**
 * Background script that will run on all Instructure pages and listen for user events in order to
 * display the toolbar or hide it.
 * onClicked listens for when the user clicks on the icon, and takes action accordingly.
 * onUpdated listens for when the user refreshes or navigates to a new page, and takes action accordingly.
 * @param {boolean} toggle - to check when the extension button has been clicked
 * @param {boolean} barStatus - to check whether the toolbar is on or off when moving to a new page
 */
var toggle = false;
var barStatus = false;

chrome.browserAction.onClicked.addListener(function(tab) {
    toggle = !toggle;
    if(toggle) {
        chrome.browserAction.setIcon({path: "iconOn-32.png", tabId: tab.id});
        chrome.tabs.executeScript(tab.id, {file: "bookmarklet.js"});
        barStatus = true;
    } else {
        chrome.browserAction.setIcon({path: "iconOff-32.png", tabId: tab.id});
        chrome.tabs.executeScript(tab.id, {code: "document.getElementById('extensionMenu').remove()"});
        barStatus = false;
    }
});

chrome.tabs.onUpdated.addListener(function(tab) {
    if(barStatus) {
        chrome.browserAction.setIcon({path: "iconOn-32.png", tabId: tab.id});
        chrome.tabs.executeScript(tab.id, {file: "bookmarklet.js"});
    } else {
        chrome.browserAction.setIcon({path: "iconOff-32.png", tabId: tab.id});
        chrome.tabs.executeScript(tab.id, {code: "document.getElementById('extensionMenu').remove()"});
    }
});